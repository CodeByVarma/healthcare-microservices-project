package com.healthcare.apigateway;

import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;


@Component
public class JwtUtil {

    private static final String SECRET = "7kF9dPq3VxY2mJ8rLw4ZtN6aHsQeBc1u9G5oR0KpXyC=";

    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()
                    .setSigningKey(SECRET.getBytes())
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
